N=int(input("nhap nhiet do "))
if(N>30):
	print("trời đang nóng")
elif(N<20):
	print("trời đang lạnh ")
else:
	print("thời tiết bình thường")
