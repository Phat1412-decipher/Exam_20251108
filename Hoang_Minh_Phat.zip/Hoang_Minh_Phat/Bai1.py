a=input("nhap so n1")
b=input("nhap so n2 ")
c =input("nhap so n3 ")
min =a
if(b<a):
	min=b
	
else:
	if(c<a):
		min =c


print(min)


