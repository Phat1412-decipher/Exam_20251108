N= int(input("nhap so nam "))
if ((N%4==0 and N%100==0) or N%400==0):
	print(" la nam nhuan")
else:
	print("ko la nam nhuan")