N=input("bạn hãy nhập mật khẩu ")
N1=input("bạn hãy xác nhận mật khẩu mới lần 2 ")
if (N==N1):
	print(" mật khẩu đã được đổi thành công ")
else:
	print(" mật khẩu không giống nhau rồi ")