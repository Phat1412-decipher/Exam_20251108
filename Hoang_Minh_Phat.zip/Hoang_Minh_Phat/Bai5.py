N=float(input("nhập số KM xe đã đi "))
if(N<=1.0):
	print(f"tốn {N*7000} đồng ")
if(1<N<5):
	print("tốn ",7000+(N-1)*6500,"đồng")
if(5<N):
	print("tốn",7000+3*6500+(N-4)*6000,"đồng")